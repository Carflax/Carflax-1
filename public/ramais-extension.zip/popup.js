// Ramais Carflax — popup. Busca a lista ao vivo do Supabase (leitura anônima da
// tabela `usuarios`) e cacheia localmente para abrir instantâneo / funcionar offline.

const SUPABASE_URL = "https://zwfvrmqffxcqurxpfewi.supabase.co";
const ANON_KEY =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inp3ZnZybXFmZnhjcXVyeHBmZXdpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzY0NDMwMzksImV4cCI6MjA5MjAxOTAzOX0.6Q02L0XYE7xWtn0AcCwN2KDTvRaYQgGwoTPLblR-VgE";

// Mesmo encurtamento do PDF: primeiro nome + segunda palavra significativa.
const PARTICULAS = new Set(["de", "da", "do", "dos", "das", "e"]);
function nomeCurto(full) {
  const parts = String(full || "").trim().split(/\s+/).filter(Boolean);
  if (parts.length <= 2) return parts.join(" ");
  const segundo = parts.slice(1).find((p) => !PARTICULAS.has(p.toLowerCase()));
  return segundo ? `${parts[0]} ${segundo}` : parts[0];
}

const listEl = document.getElementById("list");
const countEl = document.getElementById("count");
const qEl = document.getElementById("q");
const toastEl = document.getElementById("toast");

let ramais = [];

function render(items) {
  if (!items.length) {
    listEl.innerHTML = '<div class="empty">Nenhum ramal encontrado.</div>';
    return;
  }
  listEl.innerHTML = "";
  for (const r of items) {
    const row = document.createElement("div");
    row.className = "row";
    row.title = "Clique para copiar o ramal " + r.ramal;
    row.innerHTML =
      '<span class="ramal"></span><span class="nome"></span>';
    row.querySelector(".ramal").textContent = r.ramal;
    row.querySelector(".nome").textContent = r.name;
    row.addEventListener("click", () => copiar(r.ramal));
    listEl.appendChild(row);
  }
}

function aplicarFiltro() {
  const q = qEl.value.trim().toLowerCase();
  const filtrados = q
    ? ramais.filter((r) => r.name.toLowerCase().includes(q) || r.ramal.includes(q))
    : ramais;
  render(filtrados);
}

let toastTimer;
function copiar(ramal) {
  navigator.clipboard.writeText(ramal).then(() => {
    toastEl.textContent = "Ramal " + ramal + " copiado";
    toastEl.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove("show"), 1400);
  });
}

function setRamais(list) {
  ramais = list;
  countEl.textContent = list.length ? list.length + " ramais" : "";
  aplicarFiltro();
}

async function carregar() {
  // 1) mostra cache imediatamente
  try {
    const cache = await chrome.storage.local.get("ramais");
    if (cache.ramais && cache.ramais.length) setRamais(cache.ramais);
  } catch (_) {}

  // 2) busca versão fresca
  try {
    const url =
      SUPABASE_URL +
      "/rest/v1/usuarios?select=name,ramal&ramal=not.is.null&order=name.asc";
    const res = await fetch(url, {
      headers: { apikey: ANON_KEY, authorization: "Bearer " + ANON_KEY },
    });
    if (!res.ok) throw new Error("HTTP " + res.status);
    const data = await res.json();
    const list = data
      .filter((x) => x.ramal && String(x.ramal).trim() !== "")
      .map((x) => ({ ramal: String(x.ramal).trim(), name: nomeCurto(x.name || "") }))
      .sort((a, b) => a.name.localeCompare(b.name, "pt-BR"));
    setRamais(list);
    chrome.storage.local.set({ ramais: list, updatedAt: Date.now() });
  } catch (err) {
    if (!ramais.length) {
      listEl.innerHTML =
        '<div class="err">Não foi possível carregar os ramais.<br>Verifique a conexão e tente de novo.</div>';
    }
  }
}

qEl.addEventListener("input", aplicarFiltro);
carregar();
